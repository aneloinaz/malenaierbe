var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');

ctx.fillStyle = 'red';
//X, Y, zabalera, altura
ctx.fillRect(25, 25, 100, 100);